# Atrium

A secure, closed-access social platform for cardiologists to participate in discussions and share media.

## Features

- **Secure Authentication**: Invite code-based registration system
- **Admin Controls**: Create and delete topics, generate invite codes
- **Thread-based Discussions**: Organized conversations by topic
- **Media Sharing**: Support for images, videos, PDFs, and documents
- **Left Navigation**: Easy access to all discussion topics
- **Clean Modern UI**: Professional and intuitive interface

## Technical Details

This application is built using:

- **Backend**: Flask (Python)
- **Database**: MySQL
- **Frontend**: HTML, CSS (Tailwind), JavaScript (Vue.js)
- **Authentication**: Session-based with password hashing

## Project Structure

```
atrium/
├── src/
│   ├── models/          # Database models
│   │   ├── user.py      # User and invite code models
│   │   └── discussion.py # Topic, post, and attachment models
│   ├── routes/          # API endpoints
│   │   ├── user.py      # Authentication and user management
│   │   ├── discussion.py # Topic and post management
│   │   └── upload.py    # File upload handling
│   ├── static/          # Frontend files
│   │   ├── index.html   # Single-page application
│   │   └── background.jpeg # Header background image
│   └── main.py          # Application entry point
├── migrate_db.py        # Database migration script
└── requirements.txt     # Python dependencies
```

## Initial Access

- **Admin Username**: admin
- **Admin Password**: admin123
- **Initial Invite Code**: DOCTOR123

## Usage Instructions

1. **Admin Login**: Use the provided admin credentials to log in
2. **Create Topics**: Use the admin panel to create discussion topics
3. **Generate Invite Codes**: Create invite codes for cardiologists to register
4. **User Registration**: Cardiologists can register using invite codes
5. **Participate in Discussions**: Post messages and share media in topics
6. **Delete Topics**: Admins can delete topics when needed

## Customization Options

This platform can be customized for different medical specialties or research groups by:

1. Changing the branding and subheading
2. Modifying the user registration fields
3. Adding specialty-specific topic templates
4. Customizing the UI colors and styling

## Security Notes

This is a Proof of Concept (POC) implementation. For production use, consider:

- Changing the default admin password
- Implementing email verification
- Adding HTTPS encryption
- Setting up proper database backups
- Implementing rate limiting

## Future Enhancement Possibilities

- Live video streaming with OpenVidu
- AI-assisted content analysis
- Adverse event monitoring
- Transcription and analysis of video conversations
