from flask import Blueprint, jsonify, request, session, current_app
from src.models.discussion import Attachment, Post
from src.models.user import User, db
import os
import functools
import uuid
from werkzeug.utils import secure_filename

upload_bp = Blueprint('upload', __name__)

# Authentication decorator
def login_required(f):
    @functools.wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({"error": "Authentication required"}), 401
        return f(*args, **kwargs)
    return decorated_function

# Helper function to check allowed file extensions
def allowed_file(filename):
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'mp4', 'mov', 'pdf', 'doc', 'docx'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Helper function to get file type category
def get_file_type(filename):
    ext = filename.rsplit('.', 1)[1].lower()
    if ext in ['png', 'jpg', 'jpeg', 'gif']:
        return 'image'
    elif ext in ['mp4', 'mov']:
        return 'video'
    elif ext in ['pdf']:
        return 'pdf'
    elif ext in ['doc', 'docx']:
        return 'document'
    else:
        return 'other'

@upload_bp.route('/upload/<int:post_id>', methods=['POST'])
@login_required
def upload_file(post_id):
    # Check if post exists and user has permission
    post = Post.query.get_or_404(post_id)
    
    # Only allow the post author or an admin to add attachments
    if post.user_id != session['user_id']:
        current_user = User.query.get(session['user_id'])
        if not current_user.is_admin:
            return jsonify({"error": "Unauthorized"}), 403
    
    # Check if the post request has the file part
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400
    
    file = request.files['file']
    
    # If user does not select file, browser also
    # submit an empty part without filename
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    
    if file and allowed_file(file.filename):
        # Create uploads directory if it doesn't exist
        uploads_dir = os.path.join(current_app.root_path, 'static', 'uploads')
        os.makedirs(uploads_dir, exist_ok=True)
        
        # Secure the filename and add a unique identifier
        filename = secure_filename(file.filename)
        unique_filename = f"{uuid.uuid4().hex}_{filename}"
        file_path = os.path.join(uploads_dir, unique_filename)
        
        # Save the file
        file.save(file_path)
        
        # Create attachment record
        attachment = Attachment(
            filename=filename,
            file_path=f"/static/uploads/{unique_filename}",
            file_type=get_file_type(filename),
            file_size=os.path.getsize(file_path),
            post_id=post_id
        )
        
        db.session.add(attachment)
        db.session.commit()
        
        return jsonify(attachment.to_dict()), 201
    
    return jsonify({"error": "File type not allowed"}), 400

@upload_bp.route('/attachments/<int:attachment_id>', methods=['DELETE'])
@login_required
def delete_attachment(attachment_id):
    attachment = Attachment.query.get_or_404(attachment_id)
    post = Post.query.get(attachment.post_id)
    
    # Only allow the post author or an admin to delete attachments
    if post.user_id != session['user_id']:
        current_user = User.query.get(session['user_id'])
        if not current_user.is_admin:
            return jsonify({"error": "Unauthorized"}), 403
    
    # Delete the file from the filesystem
    file_path = os.path.join(current_app.root_path, attachment.file_path.lstrip('/'))
    if os.path.exists(file_path):
        os.remove(file_path)
    
    # Delete the attachment record
    db.session.delete(attachment)
    db.session.commit()
    
    return '', 204
