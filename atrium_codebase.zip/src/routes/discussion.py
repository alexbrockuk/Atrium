from flask import Blueprint, jsonify, request, session
from src.models.discussion import Topic, Post, Attachment
from src.models.user import User, db
import functools

discussion_bp = Blueprint('discussion', __name__)

# Authentication decorator
def login_required(f):
    @functools.wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({"error": "Authentication required"}), 401
        return f(*args, **kwargs)
    return decorated_function

# Admin decorator
def admin_required(f):
    @functools.wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({"error": "Authentication required"}), 401
        
        user = User.query.get(session['user_id'])
        if not user or not user.is_admin:
            return jsonify({"error": "Admin privileges required"}), 403
        
        return f(*args, **kwargs)
    return decorated_function

# Topic routes - only admins can create topics
@discussion_bp.route('/topics', methods=['POST'])
@admin_required
def create_topic():
    data = request.json
    
    if not all(k in data for k in ('title',)):
        return jsonify({"error": "Missing required fields"}), 400
    
    topic = Topic(
        title=data['title'],
        description=data.get('description', ''),
        created_by=session['user_id']
    )
    
    db.session.add(topic)
    db.session.commit()
    
    return jsonify(topic.to_dict()), 201

@discussion_bp.route('/topics', methods=['GET'])
@login_required
def get_topics():
    topics = Topic.query.order_by(Topic.created_at.desc()).all()
    return jsonify([topic.to_dict() for topic in topics])

@discussion_bp.route('/topics/<int:topic_id>', methods=['GET'])
@login_required
def get_topic(topic_id):
    topic = Topic.query.get_or_404(topic_id)
    return jsonify(topic.to_dict())

@discussion_bp.route('/topics/<int:topic_id>', methods=['PUT'])
@admin_required
def update_topic(topic_id):
    topic = Topic.query.get_or_404(topic_id)
    data = request.json
    
    if 'title' in data:
        topic.title = data['title']
    
    if 'description' in data:
        topic.description = data['description']
    
    db.session.commit()
    return jsonify(topic.to_dict())

@discussion_bp.route('/topics/<int:topic_id>', methods=['DELETE'])
@admin_required
def delete_topic(topic_id):
    topic = Topic.query.get_or_404(topic_id)
    db.session.delete(topic)
    db.session.commit()
    return '', 204

# Post routes - all authenticated users can create posts
@discussion_bp.route('/topics/<int:topic_id>/posts', methods=['POST'])
@login_required
def create_post(topic_id):
    topic = Topic.query.get_or_404(topic_id)
    data = request.json
    
    if 'content' not in data:
        return jsonify({"error": "Missing required fields"}), 400
    
    post = Post(
        content=data['content'],
        topic_id=topic_id,
        user_id=session['user_id']
    )
    
    db.session.add(post)
    db.session.commit()
    
    return jsonify(post.to_dict()), 201

@discussion_bp.route('/topics/<int:topic_id>/posts', methods=['GET'])
@login_required
def get_posts(topic_id):
    Topic.query.get_or_404(topic_id)  # Ensure topic exists
    posts = Post.query.filter_by(topic_id=topic_id).order_by(Post.created_at.asc()).all()
    
    # Include attachments in the response
    posts_with_attachments = []
    for post in posts:
        post_dict = post.to_dict()
        post_dict['attachments'] = [attachment.to_dict() for attachment in post.attachments]
        posts_with_attachments.append(post_dict)
    
    return jsonify(posts_with_attachments)

@discussion_bp.route('/posts/<int:post_id>', methods=['GET'])
@login_required
def get_post(post_id):
    post = Post.query.get_or_404(post_id)
    post_dict = post.to_dict()
    post_dict['attachments'] = [attachment.to_dict() for attachment in post.attachments]
    return jsonify(post_dict)

@discussion_bp.route('/posts/<int:post_id>', methods=['PUT'])
@login_required
def update_post(post_id):
    post = Post.query.get_or_404(post_id)
    
    # Only allow the author or an admin to update the post
    if post.user_id != session['user_id']:
        current_user = User.query.get(session['user_id'])
        if not current_user.is_admin:
            return jsonify({"error": "Unauthorized"}), 403
    
    data = request.json
    
    if 'content' in data:
        post.content = data['content']
    
    db.session.commit()
    return jsonify(post.to_dict())

@discussion_bp.route('/posts/<int:post_id>', methods=['DELETE'])
@login_required
def delete_post(post_id):
    post = Post.query.get_or_404(post_id)
    
    # Only allow the author or an admin to delete the post
    if post.user_id != session['user_id']:
        current_user = User.query.get(session['user_id'])
        if not current_user.is_admin:
            return jsonify({"error": "Unauthorized"}), 403
    
    db.session.delete(post)
    db.session.commit()
    return '', 204
