from flask import Blueprint, jsonify, request, session
from src.models.user import User, InviteCode, db
from werkzeug.security import generate_password_hash, check_password_hash
import secrets
import functools

user_bp = Blueprint('user', __name__)

# Authentication decorator
def login_required(f):
    @functools.wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({"error": "Authentication required"}), 401
        return f(*args, **kwargs)
    return decorated_function

# Admin decorator
def admin_required(f):
    @functools.wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({"error": "Authentication required"}), 401
        
        user = User.query.get(session['user_id'])
        if not user or not user.is_admin:
            return jsonify({"error": "Admin privileges required"}), 403
        
        return f(*args, **kwargs)
    return decorated_function

@user_bp.route('/register', methods=['POST'])
def register():
    data = request.json
    
    # Validate required fields
    if not all(k in data for k in ('username', 'email', 'password', 'invite_code')):
        return jsonify({"error": "Missing required fields"}), 400
    
    # Check if username or email already exists
    if User.query.filter_by(username=data['username']).first():
        return jsonify({"error": "Username already exists"}), 400
    
    if User.query.filter_by(email=data['email']).first():
        return jsonify({"error": "Email already exists"}), 400
    
    # Validate invite code
    invite_code = InviteCode.query.filter_by(code=data['invite_code'], is_used=False).first()
    if not invite_code:
        return jsonify({"error": "Invalid or already used invite code"}), 400
    
    # Create new user
    user = User(
        name=data.get('name', ''),  # Added name field with default empty string
        username=data['username'],
        email=data['email'],
        is_admin=False
    )
    user.set_password(data['password'])
    
    # Mark invite code as used
    invite_code.is_used = True
    
    # Save user and associate with invite code
    db.session.add(user)
    db.session.commit()
    
    invite_code.used_by = user.id
    user.invite_code_id = invite_code.id
    db.session.commit()
    
    return jsonify(user.to_dict()), 201

@user_bp.route('/login', methods=['POST'])
def login():
    data = request.json
    
    if not all(k in data for k in ('username', 'password')):
        return jsonify({"error": "Missing username or password"}), 400
    
    user = User.query.filter_by(username=data['username']).first()
    
    if not user or not user.check_password(data['password']):
        return jsonify({"error": "Invalid username or password"}), 401
    
    session['user_id'] = user.id
    
    return jsonify({
        "message": "Login successful",
        "user": user.to_dict()
    })

@user_bp.route('/logout', methods=['POST'])
def logout():
    session.pop('user_id', None)
    return jsonify({"message": "Logout successful"})

@user_bp.route('/current-user', methods=['GET'])
@login_required
def get_current_user():
    user = User.query.get(session['user_id'])
    return jsonify(user.to_dict())

@user_bp.route('/invite-codes', methods=['POST'])
@admin_required
def create_invite_code():
    # Generate a random invite code
    code = secrets.token_urlsafe(8)
    
    invite = InviteCode(code=code)
    db.session.add(invite)
    db.session.commit()
    
    return jsonify(invite.to_dict()), 201

@user_bp.route('/invite-codes', methods=['GET'])
@admin_required
def get_invite_codes():
    invite_codes = InviteCode.query.all()
    return jsonify([code.to_dict() for code in invite_codes])

@user_bp.route('/users', methods=['GET'])
@admin_required
def get_users():
    users = User.query.all()
    return jsonify([user.to_dict() for user in users])

@user_bp.route('/users/<int:user_id>', methods=['GET'])
@login_required
def get_user(user_id):
    user = User.query.get_or_404(user_id)
    return jsonify(user.to_dict())

@user_bp.route('/users/<int:user_id>', methods=['PUT'])
@login_required
def update_user(user_id):
    # Only allow users to update their own profile or admins to update any profile
    if session['user_id'] != user_id:
        current_user = User.query.get(session['user_id'])
        if not current_user.is_admin:
            return jsonify({"error": "Unauthorized"}), 403
    
    user = User.query.get_or_404(user_id)
    data = request.json
    
    if 'name' in data:
        user.name = data['name']
    
    if 'username' in data and data['username'] != user.username:
        if User.query.filter_by(username=data['username']).first():
            return jsonify({"error": "Username already exists"}), 400
        user.username = data['username']
    
    if 'email' in data and data['email'] != user.email:
        if User.query.filter_by(email=data['email']).first():
            return jsonify({"error": "Email already exists"}), 400
        user.email = data['email']
    
    if 'password' in data:
        user.set_password(data['password'])
    
    db.session.commit()
    return jsonify(user.to_dict())

@user_bp.route('/users/<int:user_id>', methods=['DELETE'])
@admin_required
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    return '', 204

@user_bp.route('/make-admin/<int:user_id>', methods=['POST'])
@admin_required
def make_admin(user_id):
    user = User.query.get_or_404(user_id)
    user.is_admin = True
    db.session.commit()
    return jsonify(user.to_dict())
