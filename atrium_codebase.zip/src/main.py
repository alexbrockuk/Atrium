import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory, session
from src.models.user import db
from src.routes.user import user_bp
from src.routes.discussion import discussion_bp
from src.routes.upload import upload_bp
import secrets

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = secrets.token_hex(16)
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_PERMANENT'] = True
app.config['PERMANENT_SESSION_LIFETIME'] = 86400  # 24 hours

# Register all blueprints
app.register_blueprint(user_bp, url_prefix='/api')
app.register_blueprint(discussion_bp, url_prefix='/api')
app.register_blueprint(upload_bp, url_prefix='/api')

# Enable database
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{os.getenv('DB_USERNAME', 'root')}:{os.getenv('DB_PASSWORD', 'password')}@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '3306')}/{os.getenv('DB_NAME', 'mydb')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# Create all tables
with app.app_context():
    db.create_all()
    
    # Check if we need to create an initial admin user and invite code
    from src.models.user import User, InviteCode
    admin = User.query.filter_by(is_admin=True).first()
    if not admin:
        # Create initial admin user
        admin = User(
            username="admin",
            email="admin@example.com",
            is_admin=True
        )
        admin.set_password("admin123")  # This would be changed in production
        db.session.add(admin)
        
        # Create initial invite code
        invite = InviteCode(code="DOCTOR123")
        db.session.add(invite)
        db.session.commit()
        
        print("Created initial admin user and invite code")
        print("Username: admin")
        print("Password: admin123")
        print("Invite Code: DOCTOR123")

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
            return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
