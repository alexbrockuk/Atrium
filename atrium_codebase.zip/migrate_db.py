import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask
from src.models.user import db
from sqlalchemy import text

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{os.getenv('DB_USERNAME', 'root')}:{os.getenv('DB_PASSWORD', 'password')}@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '3306')}/{os.getenv('DB_NAME', 'mydb')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def add_name_column():
    with app.app_context():
        try:
            with db.engine.connect() as conn:
                conn.execute(text("ALTER TABLE user ADD COLUMN name VARCHAR(100)"))
                conn.commit()
            print("Successfully added 'name' column to user table")
        except Exception as e:
            print(f"Error adding column: {e}")
            # If the error is that the column already exists, we can ignore it
            if "Duplicate column name" in str(e):
                print("Column 'name' already exists, continuing...")
            else:
                raise

if __name__ == '__main__':
    add_name_column()
